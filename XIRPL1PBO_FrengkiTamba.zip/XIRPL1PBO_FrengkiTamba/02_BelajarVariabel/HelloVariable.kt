fun main(){
	var nama="Frengki"
	var usia=20		
	var jeniskelamin='L'

	println("-Hello variabel- \n\n")
	println("nama $nama")
	println("usia $usia")
	println("jeniskelamin $jeniskelamin")
	usia=16
	println("usia betulnya $usia")
}