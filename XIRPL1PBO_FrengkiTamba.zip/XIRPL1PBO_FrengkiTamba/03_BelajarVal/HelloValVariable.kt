fun main(){
 var rumusPersegiPanjang ="P x P"
 val rumusSegitiga="A x T / 2"
 val rumusLingkaran="22/7"
 print("-Latihan Variable Val \n\n")
 print("info Rumus Persegi Panjang : $rumusPersegiPanjang \n")
 print("info Rumus Segitiga : $rumusSegitiga \n")
 print("info Rumus Lingkaran : $rumusLingkaran \n")
 rumusPersegiPanjang = "P x L"
 print("info Rumus Persegi Panjang OK : $rumusPersegiPanjang \n")
}