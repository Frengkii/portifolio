fun main(){
	//ini adalah type angka
	var harga:Int= 1_000_000_000
	//ini adalah type carakter
	var golonganDarah:Char= 'A'
	//ini adalah type simbol atau karakter
	var nama:String= "Frengki"
	//ini adalah type logika
	var operasiLogika:Boolean = (5 <= 5)

	println(harga)
	println(golonganDarah)
	println(nama)
	println(operasiLogika)

}