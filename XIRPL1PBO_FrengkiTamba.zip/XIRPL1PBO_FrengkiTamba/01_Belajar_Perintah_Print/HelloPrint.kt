fun main(){
println("Hello world")
print("Nama saya, ")
println("Frengki")
print("Usia ")
println("16")
print("Jenis kelamin, ")
println("Laki-laki")
print("Alamat, ")
print("Tokyo")

}