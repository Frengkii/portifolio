fun main(){
var nilai1:Int =10
var nilai2:Int =5

println("Operator Perbandingan:")
println("----------------------")
print("nilai : $nilai1 > $nilai2 = ")
println( nilai1>nilai2 )
print("nilai : $nilai1 < $nilai2 = ")
println( nilai1<nilai2 )
print("nilai : $nilai1 >= $nilai2 = ")
println( nilai1>=nilai2 )
print("nilai : $nilai1 <= $nilai2 = ")
println( nilai1<=nilai2 )
print("nilai : $nilai1 == $nilai2 = ")
println( nilai1==nilai2 )
print("nilai : $nilai1 != $nilai2 = ")
println( nilai1!=nilai2 )
}
