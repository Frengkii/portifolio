fun main(){
 var x:Int

 println("Latihan Operasi Penugasan: Frengki ")
 println("-----------------------------------")
 // =
 x=5
 println("memberi nilai x = $x")

 // +=
 x=20
 x+=5
 println("Operasi x+=5 Hasil Operasi: $x")

 // +=
 x=20
 x-=5
 println("Operasi x-=5 Hasil Operasi: $x")

 // +=
 x=20
 x*=5
 println("Operasi x*=5 Hasil Operasi: $x")

 // +=
 x=20
 x/=5
 println("Operasi x/=5 Hasil Operasi: $x")

 // +=
 x=20
 x%=5
 println("Operasi x%=5 Hasil Operasi: $x")
}