fun main(){
 var nilai1:Int
 var nilai2:Int
 var operasi:Int

	nilai1 = 4
	nilai2 = 2
	//operasi penjumlahan
	operasi = (nilai1 + nilai2)
	println("hasil : $nilai1 + $nilai2 = $operasi")

	//operasi pengurangan
	operasi = (nilai1 - nilai2) 
	println("hasil : $nilai1 - $nilai2 = $operasi")

	//operasi perkalian
	operasi = nilai1 * nilai2
	println("hasil : $nilai1 * $nilai2 = $operasi")

	//operasi pengurangan 
	operasi = nilai1 / nilai2
	println("hasil : $nilai1 / $nilai2 = $operasi")

	//operasi pengurangan
	operasi = nilai1 % nilai2
	println("hasil : $nilai1 % nilai2 = $operasi")

}