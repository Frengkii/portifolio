fun main(){
	var nilai1:Int=1
	var nilai2:Int=2
	var nilai3:Int=3
	var nilai4:Int=4

	var operasi:Boolean
	println("--------------------------------------")
	println("- Latihan Operator logika : Frengki -\n")

	operasi = ((nilai1>nilai2)&&(nilai3>nilai4))
	println("Hasil Operasi Logika AND : ")
	println(" ($nilai1 > $nilai2 && $nilai3>nilai4 ) = $operasi")

	

}