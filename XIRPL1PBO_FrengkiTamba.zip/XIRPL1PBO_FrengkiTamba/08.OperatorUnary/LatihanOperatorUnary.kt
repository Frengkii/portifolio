fun main(){
 var nilai:Int =23
 var operasi:Int
 var cekStatusMakan:Boolean = false
 var operasiLogika:Boolean
 println("-------------------------------------")
 println("- Latihan Operator Unary : Frengki - \n")

 operasi = +nilai
 println("Operasi Unary Plus : $nilai="+operasi)

 operasi = -nilai
 println("Operasi Minus Unary : $nilai="+operasi)

 operasi = ++nilai
 println("Operasi Bertambah 1 : $nilai="+operasi)

 operasi = --nilai
 println("Operasi Berkurang 1 : $nilai="+operasi)

 operasiLogika = !cekStatusMakan
 println("Operasi membalikkan nilai $cekStatusMakan : !makan = $operasiLogika")

 println("--------------------------------")
}